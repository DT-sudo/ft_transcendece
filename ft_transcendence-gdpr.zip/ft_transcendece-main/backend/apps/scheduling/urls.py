from django.urls import path

from . import views

urlpatterns = [
    path("manager/shifts/", views.manager_shifts, name="manager_shifts"),
    path("manager/shifts/create/", views.save_shift_view, name="create_shift"),
    path("manager/shifts/publish-all/", views.publish_all_shifts, name="publish_all_shifts"),
    path("manager/shifts/<int:shift_id>/update/", views.save_shift_view, name="update_shift"),
    path("manager/shifts/<int:shift_id>/delete/", views.delete_shift, name="delete_shift"),
    path("manager/shifts/<int:shift_id>/publish/", views.publish_shift_view, name="publish_shift"),
    path("manager/shifts/search/", views.manager_shift_search, name="manager_shift_search"),
    path("manager/shifts/analytics/", views.manager_analytics, name="manager_analytics"),
    path("manager/shifts/analytics/data/", views.manager_analytics_data, name="manager_analytics_data"),
    path("manager/shifts/analytics/export/csv/", views.manager_analytics_export_csv, name="manager_analytics_export_csv"),
    path("manager/positions/create/", views.position_create, name="position_create"),
    path("manager/positions/<int:position_id>/delete/", views.position_delete, name="position_delete"),
    path("employee/shifts/", views.employee_shifts_view, name="employee_shifts"),
    path("employee/unavailability/toggle/", views.employee_unavailability_toggle, name="employee_unavailability_toggle"),
]
